# KeywordsHarvester
Simple application for harvesting photos' keywords' metada
